package com.example.AR.BloodBank;



public interface Permissions {

    int PERMISSION_CODE_CALL_PHONE=0;
    String [] PERMISSIONS={android.Manifest.permission.CALL_PHONE};
}
